public class MockPatientService {
    public boolean verifierPatient(int id) {
        return id == 1;
    }

    public String getMesuresString(int id) {
        return "Tension : 120/80 mmHg\nTempérature : 36.9 °C\nSaturation O2 : 98%";
    }
}