import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class FenetreMedecin extends JFrame {

    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField patientIdField;

    public FenetreMedecin() {
        setTitle("Espace Médecin");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel du haut : ID patient + bouton rechercher
        JPanel searchPanel = new JPanel();
        searchPanel.add(new JLabel("ID du patient :"));
        patientIdField = new JTextField(10);
        searchPanel.add(patientIdField);

        JButton searchButton = new JButton("Rechercher");
        searchPanel.add(searchButton);

        JButton refreshButton = new JButton("Tout afficher");
        searchPanel.add(refreshButton);

        add(searchPanel, BorderLayout.NORTH);

        // Tableau des données
        String[] columnNames = {"ID Patient", "Température", "Fréquence cardiaque", "SpO2", "Horodatage"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Bouton retour
        JButton retourButton = new JButton("Retour");
        retourButton.addActionListener(e -> {
            this.dispose();
            new AccueilFenetre().setVisible(true);
        });
        add(retourButton, BorderLayout.SOUTH);

        // Affichage initial
        afficherTousLesPatients();

        // Action rechercher
        searchButton.addActionListener((ActionEvent e) -> {
            String patientId = patientIdField.getText().trim();
            if (!patientId.isEmpty()) {
                rechercherPatient(patientId);
            } else {
                JOptionPane.showMessageDialog(this, "Veuillez entrer un ID de patient.", "Erreur", JOptionPane.WARNING_MESSAGE);
            }
        });

        // Action tout afficher
        refreshButton.addActionListener(e -> afficherTousLesPatients());
    }

    private void rechercherPatient(String patientId) {
        VitalsService service = new VitalsService();
        try {
            List<Vitals> list = service.getVitalsByPatientId(patientId);
            afficherListe(list);
        } catch (PatientNotFoundException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Patient introuvable", JOptionPane.WARNING_MESSAGE);
            tableModel.setRowCount(0); // vider le tableau
        }
    }

    private void afficherTousLesPatients() {
        VitalsService service = new VitalsService();
        List<Vitals> list = service.getLatestVitals();
        afficherListe(list);
    }

    private void afficherListe(List<Vitals> list) {
        tableModel.setRowCount(0); // vider le tableau avant remplissage
        for (Vitals v : list) {
            tableModel.addRow(new Object[]{
                    v.getPatientId(),
                    v.getTemperature(),
                    v.getHeartRate(),
                    v.getSpo2(),
                    v.getTimestamp()
            });
        }
    }
}
