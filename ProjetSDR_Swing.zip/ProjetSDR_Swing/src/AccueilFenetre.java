import javax.swing.*;
import java.awt.*;

public class AccueilFenetre extends JFrame {
    public AccueilFenetre() {
        setTitle("Accueil - Système de surveillance de santé");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel titre = new JLabel("Bienvenue", SwingConstants.CENTER);
        titre.setFont(new Font("Arial", Font.BOLD, 20));
        add(titre, BorderLayout.NORTH);

        JPanel boutonPanel = new JPanel();
        boutonPanel.setLayout(new FlowLayout());

        JButton boutonMedecin = new JButton("Espace Médecin");
        JButton boutonPatient = new JButton("Espace Patient");

        boutonPanel.add(boutonMedecin);
        boutonPanel.add(boutonPatient);

        add(boutonPanel, BorderLayout.CENTER);

        boutonMedecin.addActionListener(e -> {
            new FenetreMedecin().setVisible(true);
            dispose();
        });

        boutonPatient.addActionListener(e -> {
            String input = JOptionPane.showInputDialog("Entrez l'ID du patient :");
            if (input != null && input.matches("\\d+")) {
                new FenetrePatient().setVisible(true);  // Tu peux passer l'ID ici si besoin
                dispose();
            }
        });
    }
}