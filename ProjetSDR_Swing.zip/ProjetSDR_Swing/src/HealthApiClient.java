import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HealthApiClient {

    public static String getVitals() {
        StringBuilder result = new StringBuilder();
        try {
            URL url = new URL("http://localhost:8080/api/vitals"); // l'URL correcte
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = rd.readLine()) != null) {
                result.append(line);
            }
            rd.close();
        } catch (Exception e) {
            e.printStackTrace();
            return "Erreur API";
        }

        return result.toString();
    }
}
