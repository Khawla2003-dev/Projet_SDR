import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class FenetrePatient extends JFrame {

    private JTextField patientIdField;
    private JTextArea vitalsArea;

    public FenetrePatient() {
        setTitle("Espace Patient");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        // Panel haut : saisie ID + bouton
        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("ID du patient :"));
        patientIdField = new JTextField(10);
        inputPanel.add(patientIdField);
        JButton searchButton = new JButton("Rechercher");
        inputPanel.add(searchButton);

        panel.add(inputPanel, BorderLayout.NORTH);

        // Zone d’affichage
        vitalsArea = new JTextArea();
        vitalsArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(vitalsArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Bouton retour
        JButton retourButton = new JButton("Retour");
        retourButton.addActionListener(e -> {
            this.dispose();
            new AccueilFenetre().setVisible(true);
        });
        panel.add(retourButton, BorderLayout.SOUTH);

        add(panel);

        // Action bouton rechercher
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String patientId = patientIdField.getText().trim();
                if (!patientId.isEmpty()) {
                    rechercherPatient(patientId);
                } else {
                    JOptionPane.showMessageDialog(null, "Veuillez entrer un ID de patient.", "Erreur", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
    }

    private void rechercherPatient(String patientId) {
        VitalsService service = new VitalsService();
        try {
            List<Vitals> vitalsList = service.getVitalsByPatientId(patientId);
            afficherVitals(vitalsList);
        } catch (PatientNotFoundException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Patient introuvable", JOptionPane.WARNING_MESSAGE);
            vitalsArea.setText(""); // effacer les données précédentes
        }
    }

    private void afficherVitals(List<Vitals> vitalsList) {
        StringBuilder sb = new StringBuilder();
        for (Vitals v : vitalsList) {
            sb.append("Température : ").append(v.getTemperature()).append(" °C\n");
            sb.append("Fréquence cardiaque : ").append(v.getHeartRate()).append(" bpm\n");
            sb.append("SpO2 : ").append(v.getSpo2()).append(" %\n");
            sb.append("Timestamp : ").append(v.getTimestamp()).append("\n");
            sb.append("-------------------------------\n");
        }
        vitalsArea.setText(sb.toString());
    }
}
