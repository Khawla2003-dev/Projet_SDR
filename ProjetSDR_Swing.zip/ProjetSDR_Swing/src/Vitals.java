public class Vitals {
    private String patientId;
    private float temperature;
    private float heartRate;
    private float spo2;
    private String timestamp;

    public Vitals(String patientId, float temperature, float heartRate, float spo2, String timestamp) {
        this.patientId = patientId;
        this.temperature = temperature;
        this.heartRate = heartRate;
        this.spo2 = spo2;
        this.timestamp = timestamp;
    }

    public String getPatientId() {
        return patientId;
    }

    public float getTemperature() {
        return temperature;
    }

    public float getHeartRate() {
        return heartRate;
    }

    public float getSpo2() {
        return spo2;
    }

    public String getTimestamp() {
        return timestamp;
    }
}
