import java.sql.*;
import java.util.*;

public class VitalsService {

    // Méthode existante pour obtenir les 10 dernières entrées
    public List<Vitals> getLatestVitals() {
        List<Vitals> data = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM vitals ORDER BY timestamp DESC LIMIT 10";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                String patientId = rs.getString("patient_id");
                float temperature = rs.getFloat("temperature");
                float heartRate = rs.getFloat("heart_rate");
                float spo2 = rs.getFloat("spo2");
                String timestamp = rs.getTimestamp("timestamp").toString();

                data.add(new Vitals(patientId, temperature, heartRate, spo2, timestamp));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return data;
    }

    // Nouvelle méthode pour obtenir les données d’un patient spécifique
    public List<Vitals> getVitalsByPatientId(String patientId) throws PatientNotFoundException {
        List<Vitals> data = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM vitals WHERE patient_id = ? ORDER BY timestamp DESC LIMIT 10";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, patientId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                float temperature = rs.getFloat("temperature");
                float heartRate = rs.getFloat("heart_rate");
                float spo2 = rs.getFloat("spo2");
                String timestamp = rs.getTimestamp("timestamp").toString();

                data.add(new Vitals(patientId, temperature, heartRate, spo2, timestamp));
            }

            // Si aucune donnée trouvée
            if (data.isEmpty()) {
                throw new PatientNotFoundException("Aucun patient trouvé avec l'ID : " + patientId);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return data;
    }
}
