public class MockMedecinService {
    public String getPatientsString() {
        return "- Samir B.\n- Layla K.";
    }

    public String getAlertesString() {
        return "- Samir B. : Température élevée (38.5°C)\n- Layla K. : Tension basse (90/60)";
    }
}